# CART3R Mod Menu

A native Kotlin Android app demonstrating an in-app developer menu for the app that contains it.

## Safety and scope

- Menu switches affect only local UI/demo state in CART3R.
- No overlay permission, accessibility service, root access, code injection, or cross-app control.
- APK selection uses Android's system document picker.
- APKs are copied to private cache with a 300 MB cap, hashed and parsed for package metadata, requested permissions and available signer certificate fingerprints.
- The APK is never installed or executed.
- This is static inspection, not a malware verdict.

## Requirements

- Android Studio
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.9.2
- Gradle 8.11.1
- Device/emulator Android 14 (API 34) or newer

## Build

1. Extract the ZIP.
2. Open the `CART3R-ModMenu` directory in Android Studio.
3. Install SDK Platform 35 if prompted and sync Gradle.
4. Run on an Android 14+ device or emulator.
5. Build an APK with Build > Build Bundle(s) / APK(s) > Build APK(s).

## Identity

- Application ID: `com.cart3r.modmenu`
- Min SDK: 34
- Target SDK: 35
- Version: 1.0.0

## Important source note

The sample is deliberately implemented as an in-app menu. If integrating it into another app you own, move the panel into a dedicated Activity/Fragment or custom view and connect each switch to a real, documented feature in that app.
