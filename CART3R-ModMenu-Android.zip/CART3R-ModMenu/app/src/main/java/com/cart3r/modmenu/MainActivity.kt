package com.cart3r.modmenu

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * CART3R Mod Menu is an in-app developer panel for the app that contains it.
 * Its toggles change local demo settings only. It does not inject code into,
 * overlay, modify, or control other applications.
 */
class MainActivity : Activity() {

    companion object {
        private const val REQUEST_OPEN_APK = 4101
        private const val MAX_APK_BYTES = 300L * 1024L * 1024L
        private const val RED = 0xFFFF3B3B.toInt()
        private const val WHITE = 0xFFEAEAEA.toInt()
        private const val MUTED = 0xFF999999.toInt()
        private const val PANEL = 0xFF171717.toInt()
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val enabledFeatures = linkedSetOf<String>()
    private lateinit var status: TextView
    private lateinit var report: TextView
    private lateinit var featurePanel: LinearLayout
    private var lastReport = ""

    private val featureNames = listOf(
        "Developer diagnostics",
        "Verbose in-app logging",
        "Experimental UI",
        "Performance overlay (demo)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setBackgroundColor(0xFF080808.toInt())
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }

        content.addView(label("CART3R", 30f, RED, true))
        content.addView(label("IN-APP MOD MENU • ANDROID 14+", 12f, MUTED, true))
        content.addView(gap(18))
        content.addView(cardTitle("CONTROL PANEL"))
        content.addView(label(
            "These controls belong to CART3R itself. They demonstrate app-local settings " +
                "and do not affect other apps or games.",
            13f, WHITE
        ))
        content.addView(gap(12))

        featurePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(PANEL)
        }
        content.addView(featurePanel)
        featureNames.forEach { addFeatureToggle(it) }

        content.addView(gap(18))
        content.addView(cardTitle("APK INSPECTOR"))
        content.addView(label(
            "Select an APK through Android's document picker to calculate its SHA-256 " +
                "and inspect package metadata and requested permissions. The APK is not installed or run.",
            13f, WHITE
        ))
        content.addView(gap(8))
        content.addView(actionButton("SELECT APK FOR ANALYSIS") { chooseApk() })

        content.addView(gap(18))
        content.addView(cardTitle("SECURITY REPORT"))
        status = label("STATUS: READY", 12f, RED, true)
        content.addView(status)
        content.addView(gap(8))
        report = label("No report generated yet.", 12f, WHITE).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(PANEL)
            setTextIsSelectable(true)
        }
        content.addView(report)
        content.addView(gap(8))
        content.addView(actionButton("COPY REPORT") { copyReport() })
        content.addView(gap(18))
        content.addView(label(
            "CART3R • Local-only demo controls • No broad storage permission required",
            10f, MUTED
        ))

        setContentView(scroll)
    }

    private fun addFeatureToggle(name: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        val text = label(name, 14f, WHITE).apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val toggle = android.widget.Switch(this).apply {
            text = "ON"
            setTextColor(RED)
            isChecked = enabledFeatures.contains(name)
            setOnCheckedChangeListener { _, checked ->
                if (checked) enabledFeatures.add(name) else enabledFeatures.remove(name)
                Toast.makeText(
                    this@MainActivity,
                    "$name ${if (checked) "enabled" else "disabled"} for this app",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        row.addView(text)
        row.addView(toggle)
        featurePanel.addView(row)
    }

    private fun chooseApk() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.android.package-archive",
                "application/octet-stream"
            ))
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_OPEN_APK)
    }

    @Deprecated("Uses Android's system document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OPEN_APK && resultCode == RESULT_OK) {
            data?.data?.let(::analyzeApk)
        }
    }

    private fun analyzeApk(uri: Uri) {
        status.text = "STATUS: ANALYZING SELECTED FILE…"
        report.text = "Copying selected APK to private cache…"

        executor.execute {
            val temp = File(cacheDir, "cart3r-${System.nanoTime()}.apk")
            try {
                copyToPrivateCache(uri, temp)
                val digest = sha256(temp)
                val packageInfo = getPackageInfo(temp)
                val result = createReport(temp, digest, packageInfo)
                runOnUiThread {
                    lastReport = result
                    report.text = result
                    status.text = "STATUS: ANALYSIS COMPLETE"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "STATUS: ANALYSIS FAILED"
                    report.text = "Analysis error: ${e.message ?: e.javaClass.simpleName}"
                }
            } finally {
                temp.delete()
            }
        }
    }

    private fun copyToPrivateCache(uri: Uri, destination: File) {
        val input = contentResolver.openInputStream(uri)
            ?: error("Cannot open the selected document.")
        input.use { source ->
            FileOutputStream(destination).use { output ->
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val count = source.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_APK_BYTES) { "File exceeds the 300 MB safety limit." }
                    output.write(buffer, 0, count)
                }
            }
        }
        require(destination.length() > 0) { "Selected file is empty." }
    }

    @Suppress("DEPRECATION")
    private fun getPackageInfo(file: File): PackageInfo {
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES
        return packageManager.getPackageArchiveInfo(file.absolutePath, flags)
            ?: error("PackageManager could not parse this APK.")
    }

    private fun createReport(file: File, fileHash: String, info: PackageInfo): String {
        val requested = info.requestedPermissions?.distinct()?.sorted().orEmpty()
        val appLabel = info.applicationInfo?.loadLabel(packageManager)?.toString() ?: "Unknown"
        val signerHashes = try {
            info.signingInfo?.apkContentsSigners?.map {
                sha256Bytes(it.toByteArray())
            }?.distinct().orEmpty()
        } catch (_: Exception) {
            emptyList()
        }

        return buildString {
            appendLine("CART3R SECURITY REPORT")
            appendLine("======================")
            appendLine("File: ${file.name}")
            appendLine("Size: ${file.length()} bytes")
            appendLine("File SHA-256: $fileHash")
            appendLine()
            appendLine("PACKAGE METADATA")
            appendLine("----------------")
            appendLine("App label: $appLabel")
            appendLine("Package: ${info.packageName}")
            appendLine("Version: ${info.versionName ?: "unspecified"}")
            appendLine("Version code: ${info.longVersionCode}")
            appendLine("Target SDK: ${info.applicationInfo?.targetSdkVersion ?: "unknown"}")
            appendLine()
            appendLine("REQUESTED PERMISSIONS (${requested.size})")
            appendLine("----------------------")
            if (requested.isEmpty()) appendLine("None reported")
            requested.forEach { appendLine("- $it") }
            appendLine()
            appendLine("SIGNER CERTIFICATE SHA-256")
            appendLine("--------------------------")
            if (signerHashes.isEmpty()) appendLine("Unavailable from this archive parse")
            signerHashes.forEachIndexed { index, hash ->
                appendLine("Signer ${index + 1}: $hash")
            }
            appendLine()
            appendLine("REVIEW NOTES")
            appendLine("------------")
            appendLine("- Requested permissions are not proof of runtime use.")
            appendLine("- This static report is not a malware verdict.")
            appendLine("- The selected APK was not installed or executed.")
            appendLine("- Review APKs only when you own them or have authorization.")
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().hex()
    }

    private fun sha256Bytes(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).hex()

    private fun ByteArray.hex(): String =
        joinToString("") { "%02x".format(it) }

    private fun copyReport() {
        if (lastReport.isBlank()) {
            Toast.makeText(this, "Generate a report first.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("CART3R report", lastReport))
        Toast.makeText(this, "Report copied.", Toast.LENGTH_SHORT).show()
    }

    private fun actionButton(caption: String, action: () -> Unit) =
        Button(this).apply {
            text = caption
            setTextColor(WHITE)
            setBackgroundColor(0xFFB71C1C.toInt())
            setOnClickListener { action() }
        }

    private fun cardTitle(value: String) = label(value, 14f, RED, true)
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun gap(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }


}
